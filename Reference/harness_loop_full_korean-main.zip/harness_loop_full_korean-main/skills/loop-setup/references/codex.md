# Codex 환경 보조 지침 (loop-setup)

## 두 입력을 읽는 방법

`plan_setup/` 과 `harness_setup/` 만 읽는다. **PRD·TRD·아키텍처는 읽지 않는다** —
루프는 요구사항을 해석하는 쪽이 아니고, 읽으면 태스크에 적히지 않은 요구를 구현하러 가게 된다.

태스크가 수십 개이므로 셸로 frontmatter 만 훑는 편이 정확하다.

```
grep -H '^id:\|^status:\|^depends_on:\|^files:\|^verification:' plan_setup/phase-*/phase-*-tasks/*.md
```

여기서 DAG 의 재료가 전부 나온다 — 노드, 간선, `blocked` 집합, `files` 겹침.
**순환과 미존재 참조는 눈으로 찾지 말고 스크립트로 확인한다.** 순환이 하나 있으면 그 태스크들은
영원히 실행 가능이 되지 않는데, 그 사실은 루프를 돌려 봐야 드러난다.

하네스 쪽은 **`## 명령` 절의 위치와 `## 활성 시점` 의 태스크 ID** 만 확인한다.
명령 내용을 `LOOP.md` 로 옮겨 적지 않는다 — 하네스가 갱신되면 옮겨 적은 쪽이 낡는다.

## `local-dev` 의 실제 옵션을 확인한다

`harness_setup/scripts/` 를 읽어 실제 파일 이름과 옵션 표기를 꺼낸다(`--status` 인지 `-Status` 인지).
`LOOP.md` 에 일반형으로 남기면 첫 세션이 추측하게 되고, 추측이 틀리면 환경 준비가 실패한 채로 게이트가 돈다.

## task_validation 을 분리된 세션으로 돌리는 방법

**이 환경에서는 자동 분리를 기대하지 않는다.** 분리는 **새 세션을 여는 것**으로 이룬다.
그래서 `LOOP.md` 에 **그대로 복사해 새 세션에 붙여 넣을 수 있는 지시문**을 만들어 둔다.
매번 손으로 다시 쓰면 매번 다른 것이 새어 나가고, 무엇이 샜는지도 기록에 안 남는다.

```
다음 태스크의 수용 기준을 실행 중인 애플리케이션에서 관찰해 판정하세요.
- 태스크 문서: plan_setup/phase-NN/phase-NN-tasks/phase-NN-task-MM.md
- 절차와 판정 형식: harness_setup/quality_gates/task_validation.md
- 애플리케이션: (접속 주소). (local-dev 명령) 으로 준비돼 있습니다
- 이 두 문서, 태스크 문서의 architecture 가 가리키는 설계 절, 실행 중인 앱 외의 정보는 찾지 마세요.
  최근 커밋·변경 파일·작업 메모를 포함해 구현 과정에 대한 어떤 설명도 참고하지 말고,
  코드를 고치지 말고, 원인 추정을 하지 마세요.
```

**구현 세션의 요약을 붙이지 않는다.** "참고하라"고 붙인 한 줄이 바로 구현 중에 형성된 판단이다.
Codex 는 저장소를 자유롭게 탐색하므로 **커밋 메시지와 최근 변경 파일이 실질적인 누수 경로**다.
그래서 위 지시문에서 그것을 명시적으로 막는다.

**같은 세션에서 구현하고 판정하는 것은 이 게이트를 돌린 것이 아니다.** 그렇게 할 수밖에 없으면
통과로 기록하지 말고 사용자에게 알린다. 통과 기록만 남으면 아무도 그 태스크를 다시 보지 않는다.

## 구동기 — 이 환경에서 세션을 여는 방법

**오르카가 있으면 ②, 없으면 ① 스크립트 구동이 기본이고 둘 다 병렬로 돈다**(11단계). 오르카 유무는 `orca --version` 으로 확인한다.
`codex exec "<지시문>"` 이 새 세션을 자식 프로세스로 띄운다. 아래는 ①의 토막별 명령이고, ①-병렬은 이것을 슬롯 트리마다 띄운다.

```
codex exec -m <8절 구현 행> -c model_reasoning_effort="<8절 구현 행>" "<LOOP.md 의 구현 지시문>"
codex exec -m <8절 검증 행> -c model_reasoning_effort="<8절 검증 행>" "<LOOP.md 의 검증 지시문>" > <OS 임시 폴더>/verdict-<태스크 ID>.txt
codex exec -m <8절 반영 행> -c model_reasoning_effort="<8절 반영 행>" "<LOOP.md 의 반영 지시문>"
```

세 지시문이 **구현 → 검증 → 반영** 세 토막이다. 구동기 스크립트는 `STATE.md` 의 `Last Verification` 과 판정 파일 유무만 보고
어느 것을 띄울지 정한다(LOOP.md 4절). 판정 파일은 저장소 밖에 둔다 — 안에 두면 반영 토막의 `git add` 에 섞인다.
구현·반영의 자동 승인 범위에 `git add`·`git commit`·`git restore` 와 판정 파일 삭제가 들어 있어야 커밋·건너뛰기·정리에서 멈추지 않고,
검증은 읽기·`local-dev`·관찰 수단만 승인한다(쓰기와 git 은 주지 않는다).

자식은 작업 디렉터리의 `AGENTS.md` 를 자동으로 읽는다 — 12단계에서 넣은 `## 루프` 절이 "LOOP.md 0절부터"를 말하므로, 지시문에는 토막(구현·검증·반영)과 태스크 ID 를 가리키는 한 줄이면 충분하다.
자식은 사람에게 물을 수 없으므로 지시문에 "물을 일이 생기면 `STATE.md` 의 `Next Action` 에 적고 종료하라"를 둔다.
승인 모드는 **구현·반영은 파일 쓰기·하네스 명령·`git add`·`git commit`·`git restore`·판정 파일 삭제, 검증은 읽기·`local-dev`·관찰 수단만** 자동 승인되는 범위로 잡고,
전체 자동 승인은 사용자가 명시적으로 켠 경우에만 쓴다.
정확한 플래그 이름은 설치된 코덱스 버전의 `codex exec --help` 로 확인한다 — 여기에 베껴 적으면 버전이 바뀔 때 낡는다.

**모델과 추론 강도는 `-m`(`--model`)과 `-c model_reasoning_effort="..."` 로 토막마다 준다.** 모델 이름(예: 최상위·보통·저비용 급이 각각 따로 있다)과
강도 값(`low|medium|high|xhigh|max|ultra`)은 설치된 버전의 모델 문서에서 확인한다 — 코덱스 모델은 몇 달 단위로 바뀌고 은퇴하므로 이름을 스크립트에 박지 않고 LOOP.md 8절 표에서 읽는다.
역할별 모델은 번호 목록 하나로 묻는다 — A) 추천대로 B) 전부 최상위 C) 전부 보통 D) 직접 지정. 각 선택지에 사용량 차이(폭 × 모델)를 붙인다.
승인·샌드박스는 `-a on-request|never` 와 `-s read-only|workspace-write|danger-full-access` 로 — 구현·반영은 `workspace-write`, 검증은 `read-only`. `--full-auto` 는 폐기 예정이라 쓰지 않는다.
①-병렬·②의 코디네이터 자식과 ②의 질문 답변 자식은 8절 코디네이터 행의 모델로 띄운다.

**①-병렬**은 라운드마다 코디네이터 트리에서 `codex exec "<코디네이터 지시문>"` 을 한 번 띄우고, `STATE.md` 의 `Assignments` 행마다 그 워커의 자리(슬롯 1 은 코디네이터 트리, 2 이상은 `worker-N` 트리)를 작업 디렉터리로
구현·검증 자식을 **백그라운드로 동시에** 띄워 전부 끝날 때까지 기다린다(셸이면 `&` 와 `wait`, PowerShell 이면 `Start-Process -Wait`).
코디네이터 트리는 세팅 때 `git worktree add <경로> -B coordinator <8절 기본 브랜치>`, 워커 트리는 `git worktree add <8절 경로> -B worker-N coordinator` 로 코디네이터가 만든다.
슬롯 1 의 `worker-1` 은 코디네이터 트리에서 돌고 워크트리는 둘째부터다. `main` 에서는 아무것도 띄우지 않는다 — 사용자의 자리다. 재배정 직전 `git reset --hard coordinator && git clean -fd`, 완료마다 기본 브랜치(8절 — `main` 이 아닐 수 있다) fast-forward.
슬롯 경로는 세팅 때 정한다 — 저장소 경로에 `OneDrive`·`Dropbox`·`iCloud`·`Google Drive` 가 들어 있으면 형제 폴더 대신 저장소 안 `.wt/worker-N`(`.gitignore` 추가)이나 동기화 밖 경로를 제안한다.
격리 3이면 스크립트가 `e2e 대기`·검증 행을 슬롯 순서대로 돌리며 앱을 전환한다(`local-dev` 내리기 → 그 슬롯 트리에서 `local-dev` → e2e 명령 → 검증 자식).
`DAG.md` 는 `harness_setup/scripts/dag-render.*` 로 만든다 — frontmatter 만 읽는 스크립트라 프로젝트 런타임으로 쓰고 셸에서 한 번 돌려 본다. 코디네이터의 승인 범위는 `STATE.md`·`LOG.md`·태스크 문서 쓰기,
`local-dev`, `git add`·`commit`·`merge`·`worktree`·`checkout`·`clean`, 결과 파일 삭제이고 코드 수정은 주지 않는다. 워커에는 `git clean`·`git merge` 를 주지 않는다.
구현 자식의 표준 출력은 `done-<ID>.txt` 로 받는다 — `TASK/STATUS/RETRY/LOG/END` 블록이고 `END` 가 없으면 중단된 것이다.
워커 자식에게는 `plan_setup/`·`harness_setup/` 문서를 읽을 **코디네이터 트리 절대 경로**와 자기 이름(`worker-N`)을 지시문에 넣는다 — 워커 트리의 문서는 낡았다.

**② 오르카**가 있으면 구동기는 **오르카 터미널 안에서 도는 `harness_setup/scripts/loop-drive.*`** 다(LOOP.md 4절의 ② 알고리즘). 코디네이터를 대화형 세션으로 상주시키지 않는다 —
판단은 ①-병렬과 같은 `codex exec "<코디네이터 지시문>"` 이 라운드마다 하고, 스크립트는 `orca orchestration task-create --spec "worker-N: <지시문>" --display-name "worker<N>_<태스크 ID>" --json` 으로 태스크를 만들고(에이전트 목록에 보이는 이름. 검증 워커는 끝에 `_검증`) `orca orchestration worker-start --task <그 id> --worktree current|path:<worker-N 워크트리> --agent codex --model <8절> --json` 으로 띄우고
`orca orchestration check --wait --types "worker_done,escalation,question" --json` 으로 받는다. 받은 배달은 처리한 뒤 다음 `check` 에 `--ack <deliveryId>` 로 확인한다.
질문은 `codex exec "<질문 답변 지시문>"`(읽기 + `STATE.md` 쓰기만 승인)에 넘겨 첫 줄이 `답:` 이면 `orca orchestration reply --id <메시지 id> --body "<답>"` 한다.
스크립트는 반드시 오르카 터미널 안에서 돈다 — 오르카 CLI 가 호출한 터미널을 코디네이터로 묶는다. Run ID 는 임시 폴더의 `loop-run.txt` 에 두고 재시작 때 `run-use --id` 로 이어받는다.
워커는 출력 블록·판정 블록을 `done-<ID>.txt`·`verdict-<ID>.txt` 에 직접 쓰고 `worker_done --report-path` 로 끝낸다. 명령 표면은 세팅 때 `orca skills get orchestration` 과 `--help` 로 확인하고,
가벼운 모델의 시험 워커 하나로 ask→reply→결과 파일→`worker_done`→`worker-release` **스모크 테스트**를 돌린다.
오르카 화면에서 카드가 `coordinator`·`worker-1`·`worker-2` 로 보이도록 `orca worktree set --worktree <id> --display-name worker-N` 을 세팅 때 한 번 한다.
코덱스에는 서브에이전트가 없으므로 ③은 해당 없다.

어느 모드든 **검증 세션은 `STATE.md`·`LOG.md` 를 쓰지 않는다.** 판정 블록을 출력하고, 옮기는 것은 구동기다.

## 파일 작성

`loop_setup/` 을 만들고 `LOOP.md` 하나를 쓴다. 파일 쓰기 도구나 heredoc 을 쓴다.
heredoc 은 구분자를 따옴표로 감싼다(`<<'EOF'`) — 안 그러면 `$` 로 시작하는 예시와 경로가 빈 문자열이 된다.

그리고 **`plan_setup/STATE.md` 를 고친다** — `# Retry` 와 `# Standing Decisions` 두 절을
`Last Verification` 뒤에 끼운다. 기존 다섯 절은 건드리지 않는다.
**앞 레이어의 산출물을 고치는 것이므로 보고에 반드시 올린다.**

승인 모드에 따라 쓰기 권한 요청이 필요하니, 작성 직전에 만들 파일과 고칠 파일을 알린다.

`loop_setup/LOOP.md` 가 이미 있으면 통째로 덮어쓰지 않는다. `loop-update` 가 진행에 맞춰 조정해 둔 규칙이
초기값으로 사라진다.

## 사용자에게 묻는 지점

선택지 UI가 없으므로 **표 하나로 모아** 제시하고 한 번에 답을 받는다. 묻는 자리는 둘이다.

```
루프를 세우기 전에 정할 것이 둘 있습니다.
("1: A, 2: B" 형태로 답해 주셔도 됩니다.)

1) 병렬로 돌립니까? (기본: 예)
   A) 예 — 구간별 폭: (표). 동시 에이전트 수 상한을 골라 주세요: (폭 최댓값) / (절반) / 1. 폭보다 큰 수는 놉니다
      격리 방식: 1) 슬롯별 환경 통째 분리(자원 N벌, local-dev 가 슬롯 변수를 받아야 함) /
                 2) DB 하나 + 슬롯별 데이터베이스·계정(권한 발급 단계 추가) / 3) 공유 자원 게이트만 직렬화(되돌리기 비용 없음)
      추천: (테스트가 DB 를 쓰면 1 또는 2 — 격리 3에서도 unit 은 병렬로 돌아 통합 테스트가 공유 DB 에서 서로 오염된다 / 안 쓰면 3)
      local-dev 가 슬롯 변수를 읽는지 확인한 결과: (읽음 / 안 읽음 — 1·2 는 harness-update 가 먼저입니다. 3 은 병렬 이득이 unit 까지입니다)
      슬롯 경로(저장소가 동기화 폴더 아래일 때만): 저장소 안 .wt/worker-N / 동기화 밖 경로
      (오르카가 있으면) 에이전트 배치: 구현 (claude/codex), 검증 (claude/codex — 구현과 다르게 두면 분리가 강해집니다), 코디네이터 (claude/codex)
   B) 아니요, 단일 에이전트         → DAG·충돌 표는 그대로 만들고 슬롯·격리는 미결로 남깁니다

   (DAG 그림은 묻지 않고 LOOP.md 8절에 그려서 보고에서 검토를 요청합니다)

2) 미활성 게이트를 달고 태스크를 완료시켜도 됩니까?
   (초기에는 코드가 없어 거의 모든 게이트가 미활성입니다. 그대로 두면 첫 태스크부터 매번 멈춥니다.)
   A) 게이트가 활성될 때까지 허용   → STATE.md 에 승인으로 기록하고 그때까지 다시 묻지 않습니다
   B) 매번 묻는다                   → 태스크마다 확인이 필요합니다
```

**"게이트가 활성될 때까지"라는 범위를 선택지에 넣는다.** 무기한 승인은 하네스를 끄는 것과 같다.

**재시도 3회·게이트 순서·분리 세션은 묻지 않는다.** 원본 사양과 Layer 4가 이미 정했다.

## 다음 단계 연결

Codex에서는 스킬 자동 호출을 기대하지 말고 다음 단계를 명시적으로 남긴다.
예: `다음 단계: loop_setup/LOOP.md 와 plan_setup/STATE.md 를 읽고 phase-01-task-01 부터 첫 사이클을 시작합니다.`

**루프 문서가 확정되기 전에는 구현에 들어가지 않는다.** 그 세션이 자기 나름의 순서를 만들면 그게 기본선이 된다.

첫 사이클부터는 이 스킬이 아니라 `LOOP.md` 가 안내한다. 미활성 게이트가 남아 있으면
그 목록과 활성 시점을 함께 남겨, 루프가 미활성을 통과로 읽지 않게 한다.
